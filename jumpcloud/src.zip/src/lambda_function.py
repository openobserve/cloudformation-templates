import boto3
import requests
import json
import os
import gzip
from base64 import b64encode
import traceback
from urllib.parse import unquote

# AWS S3 client
s3_client = boto3.client('s3')

# Configuration variables
openobserve_endpoint = os.getenv('OPENOBSERVE_ENDPOINT', 'https://o2-kinesis.onengine.io/api/default/jumpcloud/_json')
basic_auth_username = os.getenv('BASIC_AUTH_USERNAME')
basic_auth_password = os.getenv('BASIC_AUTH_PASSWORD')

# Batch size limit (adjust based on endpoint limits, e.g., 100 records)
BATCH_SIZE = 100

def lambda_handler(event, context):
    try:
        if 'Records' not in event:
            print("No 'Records' key in event.")
            print("Event received:", event)
            return

        # Process each record in 'Records'
        for record in event['Records']:
            s3_bucket = record['s3']['bucket']['name']
            s3_key = unquote(record['s3']['object']['key'])

            print(f"Processing S3 bucket: {s3_bucket}, key: {s3_key}")

            # Read and parse JSON logs from S3
            log_events = read_logs_from_s3(s3_bucket, s3_key)

            # Push logs to OpenObserve in batches
            if log_events:
                push_logs_in_batches(log_events)
            else:
                print("No logs to push.")
                
    except Exception as e:
        print(f"Error processing event: {e}")
        traceback.print_exc()

def read_logs_from_s3(bucket, key):
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        with gzip.GzipFile(fileobj=response['Body']) as gz:
            log_data = json.load(gz)  # Assumes JSON array format
        return log_data
    except s3_client.exceptions.NoSuchKey:
        print(f"The specified key does not exist in bucket '{bucket}': {key}")
        return []
    except Exception as e:
        print(f"Error reading logs from S3: {e}")
        traceback.print_exc()
        return []

def push_logs_in_batches(log_events):
    # Prepare basic auth header
    basic_auth_token = b64encode(f"{basic_auth_username}:{basic_auth_password}".encode()).decode()
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Basic {basic_auth_token}'
    }
    
    # Split log events into batches
    for i in range(0, len(log_events), BATCH_SIZE):
        batch = log_events[i:i + BATCH_SIZE]
        payload = [{"level": "info", "log": event} for event in batch]
        
        try:
            response = requests.post(openobserve_endpoint, headers=headers, json=payload)
            if response.status_code == 200:
                print(f"Batch {i // BATCH_SIZE + 1} successfully pushed to OpenObserve.")
            else:
                print(f"Failed to push batch {i // BATCH_SIZE + 1}. Status Code: {response.status_code}, Response: {response.text}")
        except Exception as e:
            print(f"Error pushing batch {i // BATCH_SIZE + 1} to OpenObserve: {e}")
            traceback.print_exc()
